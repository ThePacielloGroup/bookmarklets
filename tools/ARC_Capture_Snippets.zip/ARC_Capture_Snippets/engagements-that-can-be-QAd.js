// console.log("here");
var h2 = document.querySelector('h1+h2');
var engagementCards = document.querySelectorAll('h2+div>div');
var itemsReadyforQA = false;
Array.from(engagementCards).forEach(engagementCard => {
 var ur = engagementCard.querySelector('ul:first-child li:nth-child(3) p:nth-child(2)');
 if (ur.textContent.indexOf('0 of ')===1) {
  engagementCard.style.display='none';
 } else {
  itemsReadyforQA = true;
  ur.textContent = '👉' + ur.textContent;
  ur.style.fontWeight='bold';
  ur.style.color='darkgreen';
 }
 if (itemsReadyforQA) {
  h2.innerHTML = 'Active Engagements <div style="color:green">FILTERED: showing engagements ready for QA (Refresh to reset)</div>';
 }
});
