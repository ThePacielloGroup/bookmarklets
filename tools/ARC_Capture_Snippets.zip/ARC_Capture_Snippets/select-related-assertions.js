console.clear();
  function setrelatedIssues() {
  let componentName = document.querySelector("#full-width > div > div.row.align-items-center.mb-2 > div.col-sm-12.col-md-8.col-lg-9.col-xl-10 > div:nth-child(1) > div.col-sm-12.col-md-8").textContent.trim();
  componentName = componentName.split("Component ")[1];
  componentName = componentName.split(" (ID:")[0];
  let filtersCard;
  let searchText = "Filters:";
  var cards = document.querySelectorAll(".card");
  for (var i = 0; i < cards.length; i++) {
    if (cards[i].textContent.toLowerCase().indexOf(searchText.toLowerCase().trim())!==-1) {
      filtersCard = cards[i];
      break;
    }
  }



  const firstLevelDisclosures = document.querySelectorAll("div.row>div>.disclosure>.card-header .card-title button");
  let relatedOutputCombined = "";
  let relatedOutputParentIssue = "";
  let relatedOutputChildIssue = "";
  let relatedOutputChildIssues = "";
  let selectionMade= false;

  function insertAfter(newNode, existingNode) {
    existingNode.parentNode.insertBefore(newNode, existingNode.nextSibling);
  }

  const incrediblyInterestingWrapper = document.createElement("div");
  incrediblyInterestingWrapper.style.padding = "1em";
  incrediblyInterestingWrapper.style.outline = "4px solid darkblue";
  incrediblyInterestingWrapper.style.marginBottom = "1em";

  const instructions = document.createElement("div");
  instructions.textContent = "Press this button once done then check Console for cut-and-paste text!";
  instructions.setAttribute("tabindex", "-1");
  incrediblyInterestingWrapper.appendChild(instructions);

  const doneButton = document.createElement("button");
  doneButton.setAttribute("type", "button");
  doneButton.classList.add("btn");
  doneButton.classList.add("btn-primary");
  doneButton.textContent = "Done setting relationships";
  doneButton.addEventListener("click", (e) => {
    doneSelecting();
  });
  incrediblyInterestingWrapper.appendChild(doneButton);
  insertAfter(incrediblyInterestingWrapper, filtersCard);
  instructions.focus();

  function setParentIssue() {
    checkKeyPresses();

    Array.from(firstLevelDisclosures).forEach((firstLevelDisclosure) => {
      if (!firstLevelDisclosure.getAttribute("data-parentSet") && !firstLevelDisclosure.getAttribute("data-childSet")) {
        const newButton = document.createElement("button");
        newButton.setAttribute("type", "button");
        newButton.classList.add("btn");
        newButton.classList.add("btn-primary");
        newButton.classList.add("set-as-parent");
        newButton.setAttribute("aria-label", "Set as parent - " + firstLevelDisclosure.textContent.trim());
        newButton.textContent = "Select as parent";
        if (firstLevelDisclosure.textContent.trim() !== "Filters: None") {
          insertAfter(newButton, firstLevelDisclosure);
        }
      }
    });

    const parentButtons = document.querySelectorAll(".set-as-parent");

    let mode = "parentMode";

    Array.from(parentButtons).forEach((parentButton) => {
      parentButton.addEventListener("click", (e) => {
        const assertionButton = parentButton.previousElementSibling;
        if (mode === "parentMode") {
          assertionButton.querySelector("span").innerHTML = "<b>[PARENT]</b> " + assertionButton.textContent;
          assertionButton.style.outline = "6px solid purple";
          assertionButton.setAttribute("data-parentSet", "true");
          assertionButton.focus();
          relatedOutputParentIssue = assertionButton.textContent.trim();
          relatedOutputParentIssue = componentName + " > " + relatedOutputParentIssue + "\n\n";
          parentButton.setAttribute("hidden", "hidden");

          Array.from(firstLevelDisclosures).forEach((firstLevelDisclosure) => {
            if (!firstLevelDisclosure.getAttribute("data-parentSet") && !firstLevelDisclosure.getAttribute("data-childSet")) {
              //redefine as child buttons
              Array.from(parentButtons).forEach((parentButton) => {
                parentButton.setAttribute("aria-label", "Set as child - " + firstLevelDisclosure.textContent.trim());
                parentButton.classList.remove("set-as-parent");
                parentButton.classList.add("set-as-child");
                parentButton.textContent = "Select as child";
              });
            }
          });
          mode = "childMode";
        } else {
          //child mode
          assertionButton.querySelector("span").innerHTML = "<b>[CHILD]</b> " + assertionButton.textContent;
          assertionButton.style.outline = "3px solid green";
          assertionButton.setAttribute("data-childSet", "true");
          assertionButton.focus();
          relatedOutputChildIssue = assertionButton.textContent.trim();
          relatedOutputChildIssues += componentName + " > " + relatedOutputChildIssue + "\n\n";
          parentButton.setAttribute("hidden", "hidden");
        }
      });
    });
  }

  function checkKeyPresses() {
    document.addEventListener("keydown", function (e) {
      if (e.key === "a") {
        // doItAgain();
      }
      if (e.key === "d") {
        // doneSelecting();
      }
    });
  }

  function hideAllChildButtons() {
    const childButtons = document.querySelectorAll(".set-as-child");
    Array.from(childButtons).forEach((childButton) => {
      childButton.setAttribute("hidden", "hidden");
    });
  }

  function doItAgain() {
    hideAllChildButtons();
    setParentIssue();
  }

  function doneSelecting() {
    if (!selectionMade) {
      hideAllChildButtons();
      relatedOutputCombined = "👉 PASTE THIS IN PARENT ISSUE:\n\nRelated Issues\n\n" + relatedOutputChildIssues + "👉 PASTE THIS IN ALL CHILD ISSUES:\n\nRelated Issues\n\n" + relatedOutputParentIssue + "========================\n\n";
      relatedOutputCombined = relatedOutputCombined.split("[PARENT] ").join("");
      relatedOutputCombined = relatedOutputCombined.split("[CHILD] ").join("");
      //add to textarea for copy/paste
      const textarea = document.createElement("textarea");
      textarea.setAttribute("aria-label", "Relationship info for you to copy/paste");
      textarea.setAttribute("id", "relationships");
      textarea.style.margin = "1em 0";
      textarea.style.padding = "1em";
      textarea.style.width = "100%";
      textarea.style.height = "200px";
      textarea.style.outline = "4px solid darkblue";
      textarea.value = relatedOutputCombined;
      incrediblyInterestingWrapper.appendChild(textarea);
      textarea.focus();
      textarea.select();
      selectionMade=true;
    }
  }

  setParentIssue();
}

setrelatedIssues();
