var table = document.querySelector("table");
var trs = table.querySelectorAll("tbody tr");
var ARCidList="";
var ARCComponentTitle="";

var inProgress="";
var completed="";
var underReview="";
var componentCount = 0;
var inProgressCount = 0;
var underReviewCount = 0;
var completedCount = 0;
var status = "";

var results = "";

Array.from(trs).forEach((tr) => {
  status = tr.querySelector("td:nth-of-type(4)").textContent.trim();
  ARCIds = tr.querySelector("td").textContent.trim();
  ARCComponentTitles = tr.querySelector("th").textContent.trim();
  ARCidList += ARCIds + "\n";
  ARCComponentTitle += ARCComponentTitles + "\n";
  componentCount++;
  if (status === "In Progress") {
    inProgress += "* " + ARCIds + " - " + ARCComponentTitles + "\n";
    inProgressCount++;
  }
  if (status === "Under Review") {
    underReview += "* " + ARCIds + " - " + ARCComponentTitles + "\n";
    underReviewCount++;
  }
  if (status === "Completed") {
    completed += "* " + ARCIds + " - " + ARCComponentTitles + "\n";
    completedCount++;
  }
});

var progressbar = "";
var progressList = "\n\n█ Completed: " + completedCount + "/" + componentCount + "\n▄ Under Review: " + underReviewCount + "/" + componentCount + "\n▁ In Progress: " + inProgressCount + "/" + componentCount;


var completedCountSortaPercentage = Math.round((completedCount / componentCount) * 40);
var underReviewCountSortaPercentage = Math.round((underReviewCount / componentCount) * 40);
var inProgressCountSortaPercentage = Math.round((inProgressCount / componentCount) * 40);

if (completedCount !== 0) {
  for (let i = 0; i < completedCountSortaPercentage; i++) {
    progressbar += "█";
  }
  completedCount = " (" + completedCount + ")";
} else {
  completedCount = "";
}

if (underReviewCount !== 0) {
  for (let i = 0; i < underReviewCountSortaPercentage; i++) {
    progressbar += "▄";
  }
  underReviewCount = " (" + underReviewCount + ")";
} else {
  underReviewCount = "";
}

if (inProgressCount !== 0) {
  for (let i = 0; i < inProgressCountSortaPercentage; i++) {
    progressbar += "▁";
  }
  inProgressCount = " (" + inProgressCount + ")";
} else {
  inProgressCount = "";
}

if (inProgress === "") inProgress = "- None - \n";
if (underReview === "") underReview = "- None - \n";
if (completed === "") completed = "- None - \n";

results =
  "# Engagement Status:\n\n0⎹" +
  progressbar +
  "⎸" +
  componentCount +
  progressList +
  "\n\n## In Progress" +
  inProgressCount +
  ":\n" +
  inProgress +
  "\n## Under Review" +
  underReviewCount +
  ":\n" +
  underReview +
  "\n## Completed" +
  completedCount +
  ":\n" +
  completed;
console.clear();
console.log(results);
results;