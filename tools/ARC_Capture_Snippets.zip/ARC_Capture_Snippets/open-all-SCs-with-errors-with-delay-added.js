//open all SCs with errors disclosures
console.clear();
var delay=1000;
var SCsWithErrorsCount = 0;
var RulesWithErrorsCount = 0;
var errorIndicators = document.querySelectorAll('.badge-pill.badge-danger');
var output="";
var rule="";
var SC="";
var summarySCreport="";
var componentTitle = document.querySelector("[aria-label='Component details'] li:nth-of-type(1) p:nth-of-type(2)").textContent.trim();

function findAncestor (el, sel) {
 while ((el = el.parentElement) && !((el.matches || el.matchesSelector).call(el,sel)));
 return el;
}

Array.from(errorIndicators).forEach(errorIndicator => {
 var disclosureButton = errorIndicator.parentNode.previousElementSibling.querySelector("button");
 SCsWithErrorsCount++;
 setTimeout(function(){
  disclosureButton.click();
 }, delay);
 delay+=1200;
});

setTimeout(function(){
 var errorIndicators = document.querySelectorAll('table table .badge-pill.badge-danger');
 Array.from(errorIndicators).forEach(errorIndicator => {
  var innerTable = findAncestor(errorIndicator,"table");
  var SC = innerTable.parentNode.parentNode.previousElementSibling.querySelector("button").textContent.trim();
  rule = errorIndicator.parentNode.previousElementSibling.querySelector("a").textContent;
  if (summarySCreport.indexOf(SC)===-1) {
   summarySCreport+= "\n"+ SC + "\n";
  }
  summarySCreport+= "* " + rule + "\n";
  RulesWithErrorsCount++;
 });
 if (SCsWithErrorsCount>0) {
  output = "COMPONENT: " + componentTitle + "\n====================================================\n\n" + SCsWithErrorsCount + " SCs have issues logged against them (" + RulesWithErrorsCount + " assertions)\n---------------------------\n" + summarySCreport; 
  alert(output);
  console.log(output);
 }
}, delay+1000);



