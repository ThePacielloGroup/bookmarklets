//open all SCs and topics in one click
console.clear();
var criterionDisclosureButtons = document.querySelectorAll('.criterion>button');
Array.from(criterionDisclosureButtons).forEach(criterionDisclosureButton => {
  criterionDisclosureButton.click();
});

setTimeout(function(){
var explanations = document.querySelectorAll('th.rule a+span');
Array.from(explanations).forEach(explanation => {
  explanation.remove();
});
}, 200);



