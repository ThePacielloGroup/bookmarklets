var completedCount=0;
var QACompleted="";
var table = document.querySelector("table");
var trs = table.querySelectorAll("tbody tr");
var componentCount = trs.length;

Array.from(trs).forEach(tr => {
 status = tr.querySelector("td:nth-of-type(4)").textContent.trim();
 if (status==="Completed") {
  completedCount++;
 }
});
if (completedCount===componentCount) {
 QACompleted = "🎉🎉🎉 Hurrah! All components completed! 🎉🎉🎉";
}
QACompleted;
