//open all assertion disclosures
var firstLevelDisclosures = document.querySelectorAll('div.row>div>.disclosure>.card-header .card-title button');
Array.from(firstLevelDisclosures).forEach(firstLevelDisclosure => {
 firstLevelDisclosure.click();
});
//open all assertion targets disclosures
var targetDisclosures = document.querySelectorAll('div.row>div>.disclosure>.card-body>div>:nth-child(2) button');
Array.from(targetDisclosures).forEach(targetDisclosure => {
 targetDisclosure.click();
});
//open all assertion qa remediation notes disclosures
var QADisclosures = document.querySelectorAll('div.row>div>.disclosure>.card-body>div>:nth-child(4) button');
Array.from(QADisclosures).forEach(QADisclosure => {
 QADisclosure.click();
});
//open all assertion qa notes disclosures
var remediationNotesDisclosures = document.querySelectorAll('div.row>div>.disclosure>.card-body>div>:nth-child(3) button');
Array.from(remediationNotesDisclosures).forEach(remediationNotesDisclosure => {
 remediationNotesDisclosure.click();
});
//highlight assertions without targets
var output="";
var componentTitle = document.querySelector("[aria-label='Component details'] li:nth-of-type(1) p:nth-of-type(2)").textContent.trim();
function findAncestor (el, sel) {
 while ((el = el.parentElement) && !((el.matches || el.matchesSelector).call(el,sel)));
 return el;
}
function findElementsByTextContent(searchText,elType){
 output="";
 var assertionsWithoutTargetsCount=0;
 var elTypesToCheck = document.querySelectorAll(elType);
 for (var i = 0; i < elTypesToCheck.length; i++) {
   if (elTypesToCheck[i].textContent.toLowerCase().trim() === searchText.toLowerCase().trim()) {

     elTypesToCheck[i].style.outline="4px dotted red";
     assertionsWithoutTargetsCount++;
     let parentAssertion = findAncestor(elTypesToCheck[i],".disclosure.card");
     parentAssertion = findAncestor(parentAssertion,".disclosure.card");
     parentAssertion.style.outline="4px dotted red";
     let parentAssertionTrigger = parentAssertion.querySelector(".card-header button");
     let parentAssertionTitle = parentAssertionTrigger.textContent;
     output+="* " + parentAssertionTitle +"\n";
   }
 }
 if (assertionsWithoutTargetsCount>0) {
  output = componentTitle + "\n\nAssertions without targets found = " + assertionsWithoutTargetsCount + "\n------------------------------------\n" + output;
  alert(output);
 }
}
findElementsByTextContent("0 Target selected","button");
output;
//make assertions full width
var mainPanel = document.querySelector(".col-sm-12.col-md-8.col-lg-9");
mainPanel.classList.remove("col-md-8");
mainPanel.classList.remove("col-lg-9");//remove qa filter sidebar
document.querySelector(".col-sm-12.col-md-4.col-lg-3.bg-light").remove();