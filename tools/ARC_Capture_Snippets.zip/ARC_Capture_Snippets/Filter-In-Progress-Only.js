var componentCount=0;
var completedCount=0;
var filterCount=0;
var table = document.querySelector("table");
var trs = table.querySelectorAll("tbody tr");
componentCount = trs.length;
console.clear();
Array.from(trs).forEach(tr => {
 tr.removeAttribute("style");
 status = tr.querySelector("td:nth-of-type(4)").textContent.trim();
 if (status==="Completed") {
  completedCount++;
 }
 if (status!=="In Progress") {
  tr.style.display="none";
 } else {
  filterCount++;
 }
});
if (completedCount===componentCount) {
 console.log("🎉🎉🎉 Hurrah! All components completed! 🎉🎉🎉")
}
console.log(filterCount + " items In Progress");
filterCount;
